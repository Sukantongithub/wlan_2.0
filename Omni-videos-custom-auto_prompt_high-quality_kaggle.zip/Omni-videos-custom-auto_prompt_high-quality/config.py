# ==============================================================================
# Omni Video Factory - Master Configuration
# ==============================================================================
# All configurable settings must be defined here with default values.
# Environment variables can be used as optional runtime overrides.
# ==============================================================================

import os
from pathlib import Path

# ------------------------------------------------------------------------------
# 1. Application & Server Settings
# ------------------------------------------------------------------------------
APP_TITLE = "Omni Video Factory"
APP_HOST = "0.0.0.0"
APP_PORT = int(os.getenv("PORT", "7860"))
GRADIO_SHARE = os.getenv("GRADIO_SHARE", "auto").lower() in ("true", "1", "yes", "auto")

DEFAULT_SCENE_COUNT = 1
DEFAULT_RESOLUTION = 384
DEFAULT_ASPECT_RATIO = "3:4"
DEFAULT_SECONDS_PER_SCENE = 3

# UI Display Toggles (Set to True to restore original banners and promo blocks)
SHOW_HEADER_BANNER = os.getenv("SHOW_HEADER_BANNER", "false").lower() in ("true", "1", "yes")
SHOW_FOOTER_INFO = os.getenv("SHOW_FOOTER_INFO", "false").lower() in ("true", "1", "yes")
SHOW_UPSELL_CARD = os.getenv("SHOW_UPSELL_CARD", "false").lower() in ("true", "1", "yes")
SHOW_DOWNLOAD_UPSELL = os.getenv("SHOW_DOWNLOAD_UPSELL", "false").lower() in ("true", "1", "yes")

# ------------------------------------------------------------------------------
# 2. Model Manifest & Repositories
# ------------------------------------------------------------------------------
DEFAULT_OMNI_VIDEOS = (
    "wan_2.1_vae.safetensors@Comfy-Org/Wan_2.1_ComfyUI_repackaged@split_files/vae/wan_2.1_vae.safetensors"
    "#umt5_xxl_fp8_e4m3fn_scaled.safetensors@Comfy-Org/Wan_2.1_ComfyUI_repackaged@split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"
    "#wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High.safetensors@jorgmikel76/wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High@wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High.safetensors"
    "#wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8Low.safetensors@jorgmikel76/wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High@wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8Low.safetensors"
)

OMNI_RUNTIME_GIT_REPO = "selfitcamera/ComfyUIVideo"
OMNI_RUNTIME_GIT_REF = "17b9fb3"
OMNI_RUNTIME_GIT_USER = "selfitcamera"
OMNI_WORKFLOW_REPO = "FrameAI4687/AI-Video-0213-02"
OMNI_LLM_API_BASE = "https://omnifilm.net"

# ------------------------------------------------------------------------------
# 3. Google Colab & GPU / VRAM Optimization Settings
# ------------------------------------------------------------------------------
COLAB_OPTIMIZATION_ENABLED = True

# ComfyUI VRAM management mode: 'lowvram' (recommended for Colab 15GB), 'medvram', or 'normal'
COMFY_VRAM_STATE = "lowvram"

# Amount of VRAM (in GB) to reserve strictly for CUDA kernels and activation tensors
COMFY_RESERVE_VRAM_GB = 1.5

# Precision options for Colab 15GB VRAM
COMFY_FORCE_FP8_TEXT_ENCODER = True
COMFY_FORCE_FP16_VAE = True

# VAE Tiled decoding (prevents 4-6 GB VRAM spike when decoding 49-81 video frames)
COMFY_ENABLE_VAE_TILING = True
COMFY_VAE_TILE_SIZE = 256

# Sequential model unloading: unload text encoder before UNet, unload UNet before VAE
COMFY_UNLOAD_MODELS_BETWEEN_STAGES = True

# Enable TensorFloat-32 on Ampere+ GPUs (improves speed without quality loss)
TORCH_ALLOW_TF32 = True

# ------------------------------------------------------------------------------
# 3b. Kaggle & Multi-GPU (2*T4) Optimization Settings
# ------------------------------------------------------------------------------
KAGGLE_OPTIMIZATION_ENABLED = os.getenv("KAGGLE_OPTIMIZATION_ENABLED", "true").lower() in ("true", "1", "yes")

# Multi-GPU acceleration toggles (automatically active when torch.cuda.device_count() >= 2)
ENABLE_MULTI_GPU = os.getenv("ENABLE_MULTI_GPU", "true").lower() in ("true", "1", "yes")

# Multi-GPU execution strategy:
# 'auto': automatically pool workers and parallelize scenes across dual GPUs
# 'worker_pool': run concurrent request workers on GPU 0 and GPU 1
# 'parallel_scenes': split multi-scene video generation across GPU 0 and GPU 1
# 'single': force single GPU execution
MULTI_GPU_MODE = os.getenv("MULTI_GPU_MODE", "auto").strip().lower()

# Maximum concurrent GPU worker instances (set to 2 for Kaggle 2*T4)
MULTI_GPU_MAX_WORKERS = int(os.getenv("MULTI_GPU_MAX_WORKERS", "2"))

# Concurrency limit for Gradio queue (defaults to 2 on multi-GPU)
GRADIO_CONCURRENCY = int(os.getenv("GRADIO_CONCURRENCY", "2"))

# Parallel multi-scene generation across dual GPUs (scene 1 on GPU 0, scene 2 on GPU 1)
PARALLEL_SCENE_GENERATION = os.getenv("PARALLEL_SCENE_GENERATION", "true").lower() in ("true", "1", "yes")

# Kaggle storage directories
# Kaggle /kaggle/working has a ~20GB limit. Storing 37GB models requires using /tmp or /kaggle/input
KAGGLE_INPUT_DIR = os.getenv("KAGGLE_INPUT_DIR", "/kaggle/input")
KAGGLE_TMP_MODELS_DIR = os.getenv("KAGGLE_TMP_MODELS_DIR", "/tmp/omni_models")
KAGGLE_AUTO_DISCOVER_DATASETS = os.getenv("KAGGLE_AUTO_DISCOVER_DATASETS", "true").lower() in ("true", "1", "yes")
KAGGLE_REDIRECT_MODELS_TO_TMP = os.getenv("KAGGLE_REDIRECT_MODELS_TO_TMP", "true").lower() in ("true", "1", "yes")

# Clean VRAM cache on all GPUs
CLEANUP_ALL_GPUS = os.getenv("CLEANUP_ALL_GPUS", "true").lower() in ("true", "1", "yes")

# ------------------------------------------------------------------------------
# 4. System RAM Management Settings
# ------------------------------------------------------------------------------
# System RAM warning threshold (Colab standard has ~12 GB RAM)
RAM_MAX_PERCENT_THRESHOLD = 85.0

# Run explicit garbage collection between scenes and stages
GC_BETWEEN_SCENES = True

# Memory-map safetensors file loading on CPU to avoid duplicating 14GB files in heap
USE_MMAP_WEIGHT_LOADING = True

# Aggressively unload finished models (UNet/Text Encoder) to meta device during stage transitions,
# preventing ComfyUI from dumping 14.3 GB of model weights into host CPU RAM when loading VAE.
COMFY_OFFLOAD_TO_META_DEVICE = os.getenv("COMFY_OFFLOAD_TO_META_DEVICE", "true").lower() in ("true", "1", "yes")
COMFY_MODEL_OFFLOAD_THRESHOLD_GB = float(os.getenv("COMFY_MODEL_OFFLOAD_THRESHOLD_GB", "2.0"))

# Disable background ComfyUI-Manager registry polling during generation to save RAM and CPU threads
COMFY_MANAGER_OFFLINE = os.getenv("COMFY_MANAGER_OFFLINE", "true").lower() in ("true", "1", "yes")

# Enable Linux NVMe swap memory on Google Colab (if supported by container environment)
ENABLE_COLAB_SWAP = os.getenv("ENABLE_COLAB_SWAP", "false").lower() in ("true", "1", "yes")
COLAB_SWAP_SIZE_GB = int(os.getenv("COLAB_SWAP_SIZE_GB", "12"))
COLAB_SWAP_FILE_PATH = os.getenv("COLAB_SWAP_FILE_PATH", "/content/swapfile")

# ------------------------------------------------------------------------------
# 5. Disk Storage & Cleanup Settings
# ------------------------------------------------------------------------------
# Automatically purge intermediate frame PNGs and temp video chunks after generation
CLEAN_TEMP_AFTER_GENERATION = True

# Purge Hugging Face hub cache blobs after moving models to ComfyUI models directory
# (Prevents storing 36.7 GB models twice on the 107 GB disk)
CLEAN_HF_CACHE_AFTER_DOWNLOAD = True

# Maximum number of final output video files to retain in datas/outputs/
MAX_STORED_OUTPUT_VIDEOS = 20

# Maximum age (in hours) before temporary files in datas/temp are deleted
MAX_TEMP_FILE_AGE_HOURS = 2

# Minimum free disk space (in GB) required before allowing a new generation to start
MIN_FREE_DISK_GB_FOR_GENERATION = 3.0

# Emergency cleanup if disk usage exceeds this percentage
AUTO_EMERGENCY_CLEANUP = True

# ------------------------------------------------------------------------------
# 6. Automatic Resource Monitoring Settings
# ------------------------------------------------------------------------------
MONITOR_RESOURCES_ENABLED = True
VRAM_WARNING_THRESHOLD_PERCENT = 90.0
RAM_WARNING_THRESHOLD_PERCENT = 85.0
DISK_WARNING_THRESHOLD_PERCENT = 90.0
LOG_RESOURCE_SNAPSHOT_ON_START = True

# ------------------------------------------------------------------------------
# 7. Google Drive Integration (Optional Colab Persistence)
# ------------------------------------------------------------------------------
# When enabled in Colab, models can be loaded from / saved to Google Drive
ENABLE_GDRIVE_PERSISTENCE = False
GDRIVE_MOUNT_PATH = "/content/drive/MyDrive/OmniVideo"
GDRIVE_SYNC_MODELS = True
GDRIVE_SAVE_OUTPUTS = True

# ------------------------------------------------------------------------------
# 8. Generation Time Estimation & Budgets
# ------------------------------------------------------------------------------
GPU_DEFAULT_FIXED_SECONDS = 120
GPU_MIN_SECONDS = 20
GPU_MAX_SECONDS = 600
GPU_BASE_SECONDS_BY_RES = {"384": 27.0, "512": 55.0, "800": 120.0}
GPU_SCENE_EXTRA_FACTOR = 0.8
GPU_SECONDS_5_MULTIPLIER = 1.6
GPU_MODE_MULTIPLIER = {"t2v": 1.0, "i2v": 1.0, "v2v": 1.0}
GPU_BUFFER_RATIO_DEFAULT = 1.3
GPU_BUFFER_SECONDS_DEFAULT = 30.0

# ------------------------------------------------------------------------------
# 9. Policy & Filter Settings (Privacy Build)
# ------------------------------------------------------------------------------
NSFW_ENABLE = False
NSFW_BLOCK_AFTER_HITS = 3
NSFW_WARN_AFTER_HITS = 1
NSFW_REMOTE_BLOCK_AFTER_TOTAL = 5
NSFW_COUNTER_ENDPOINT = ""
NSFW_REMOTE_TIMEOUT_SECONDS = 3
NSFW_FAIL_OPEN = True
NSFW_LABEL_KEYWORDS = ("nsfw", "nude", "explicit")
NSFW_MODEL_ID = ""
NSFW_SAMPLE_RATIOS = (0.2, 0.5, 0.8)

# ------------------------------------------------------------------------------
# 10. Redis & Usage Analytics Settings (Privacy Build - Disabled)
# ------------------------------------------------------------------------------
REDIS_ENABLE = False
REDIS_KEY = ""
REDIS_URL = ""
REDIS_MEMORY_CHECK_INTERVAL_SECONDS = 120
REDIS_FLUSH_ALL_RATIO = 0.95
REDIS_MAX_CONNECTIONS = 1
REDIS_USAGE_TTL_SECONDS = 604800
REDIS_GEO_TTL_SECONDS = 15552000
IP_COUNTRY_CACHE_TTL_SECONDS = 86400
IP_COUNTRY_ENABLE_GEO_LOOKUP = False
IP_COUNTRY_LOOKUP_TIMEOUT_SECONDS = 2
COUNTRY_GENERATION_STATS_INTERVAL = 20
AUTO_PROMPT_WINDOW_SECONDS = 60
AUTO_PROMPT_MAX_PER_WINDOW = 5
AUTO_PROMPT_COUNTRY_TOTAL_LIMITS = {}
AUTO_PROMPT_LIMIT_MESSAGE = (
    "Auto-prompt is temporarily unavailable. Please enter an English prompt manually."
)
