# Omni-Video-Factory — public-models build (no secrets, no filter, no tracking)

A fully self-contained copy of the Omni-Video-Factory Space that works on a
fresh duplicate with NO environment variables or secrets:

- Model manifest is BUILT IN (DEFAULT_OMNI_VIDEOS in src/app_lib.py) and points
  at four PUBLIC Hugging Face files:
    * Comfy-Org/Wan_2.1_ComfyUI_repackaged - WAN VAE + UMT5-XXL text encoder
    * jorgmikel76/wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High - the
      WAN 2.2 14B "EnhancedNSFWCameraPrompt" high/low-noise FP8 model pair
      (the same model family the original space loads).
- The ComfyUI runtime is cloned from the PUBLIC repo selfitcamera/ComfyUIVideo
  (commit 17b9fb3) - no GitHub token required (the token gate was removed).
- The workflows load the models via ComfyUI's standard UNETLoader (GGUF
  loaders converted) - no model files need to be shipped in the repo.

## Removed (privacy/filter build)
- NSFW filter: src/config.pyc has NSFW_ENABLE=false and the code's
  _nsfw_enabled()/_nsfw_policy_applies() hard-return False, so the filter can
  never be re-enabled by config or env.
- Redis usage tracking disabled (redis = None): no per-IP counters, no country
  stats, no NSFW hit counting, no IP sets.
- Country/IP geo disabled (_request_country returns ""): no geo header reads,
  no external lookups to ipwho.is / ipapi.co. IPs never leave the server.
- Console snapshot logging disabled (_log_usage_snapshot no-op): no
  "用量统计 ... IP=..." lines in the Space logs.
- External LLM disabled (_llm_generate_scene_prompt_text): auto-scene splits
  prompts locally; no prompt text is POSTed to omnifilm.net or anywhere else.
- Gradio analytics remains (anonymous pings to gradio.app; no content).

## Deploy
1. Create a new Space: https://huggingface.co/new-space
   - SDK: Gradio, Python 3.12 (README frontmatter already sets this).
2. Upload the contents of this zip as the repo root (web UI: Add file ->
   Upload files, or git push).
3. Settings -> Hardware -> ZeroGPU (Nvidia L4S).
4. Settings -> Storage -> increase persistent storage to >= 50 GB (models are
   ~35 GB; HF grants this to ZeroGPU spaces on request, usually free).
   REQUIRED - the default 20 GB is not enough for the two 14.3 GB models.
5. Wait for first boot: it downloads the 4 models (~35 GB) and clones the
   Comfy runtime; first generation takes a while after the Space appears
   "Running". Watch the Space logs for "using workflow dir" / "runtime ready"
   / "all required models".

No env vars are needed. Optional overrides if you ever want them:
- OMNI_VIDEOS - replace the built-in model manifest (same 4-part #-format).
- HF_TOKEN - only if you point OMNI_VIDEOS at gated repos.
- GITHUB_TOKEN - only if you change OMNI_RUNTIME_GIT_REPO to a private repo.
- Do NOT set OMNI_PRIVATE_CONFIG_B64 / OMNI_PRIVATE_CONFIG_PY: they
  regenerate src/config.pyc at boot and could re-enable the filter.

## Pointing the Perchance page at it
Set CFG.api in the Perchance generator's index.html to:
  https://<your-username>-<space-name>.hf.space/gradio_api

## Running in Google Colab

The project is fully optimized for standard Google Colab environments (15 GB GPU VRAM, 12 GB System RAM, 107 GB Disk):

1. **Open Colab & Enable GPU**:
   - In Google Colab, select **Runtime -> Change runtime type -> T4 GPU** (or A100 / L4).

2. **Clone the Repo or Upload Files**:
   ```bash
   !git clone <your-repo-url>
   %cd Omni-videos-custom-auto_prompt_high-quality
   ```

3. **Install Dependencies (Disk-Optimized)**:
   ```bash
   !pip install --no-cache-dir -r requirements.txt
   ```

4. **Launch Application**:
   *(Colab 12GB RAM protection is fully automated via `colab_safe_free_memory` hook in `src/app_lib.py`)*
   ```bash
   !python colab_setup.py
   ```
   Or open and run `Omni_Video_Factory_Colab.ipynb` directly.

6. **(Optional) Google Drive Model Caching**:
   - Mount Google Drive before launching (`drive.mount('/content/drive')`).
   - The app will store and reuse the ~37 GB model files in `/content/drive/MyDrive/OmniVideo/models`, completely bypassing the re-download on subsequent sessions and saving local Colab disk space.

## Running on Kaggle (Dual Tesla T4 GPUs: 2*T4)

The project is fully engineered to run on **Kaggle Notebooks with GPU T4 x2 (Dual T4 GPUs, 30 GB VRAM total, 30 GB System RAM)**:

### Key Kaggle & Dual-T4 Optimizations:
- **Dual-GPU Acceleration (2*T4 Utilization)**:
  - Both GPU 0 (15 GB) and GPU 1 (15 GB) are automatically initialized and pooled.
  - Multi-scene generation (e.g. 2, 3, or 4 scenes) parallelizes scene generation across both GPUs simultaneously, cutting generation time in half (2x speedup)!
  - Concurrent Gradio requests are load-balanced across GPU 0 and GPU 1.
- **Kaggle 20 GB Disk Quota Protection**:
  - Kaggle enforces a strict 20 GB disk limit in `/kaggle/working`.
  - The launcher automatically redirects large model files (~37 GB) to `/tmp/omni_models` on Kaggle's fast 73 GB scratch partition and creates symlinks, preventing any `Disk full` crashes.
- **Instant Kaggle Dataset Auto-Discovery**:
  - Pre-attached Kaggle datasets in `/kaggle/input/` are automatically scanned. If the model files exist in any attached dataset, they are symlinked instantly with **0-minute download time** and **0 MB disk used**!
- **Automatic Public URL**:
  - Automatic `https://xxxx.gradio.live` link generation.

### Quick Start on Kaggle:

1. **Create Kaggle Notebook & Configure Hardware**:
   - In Kaggle, open a new or existing Python notebook.
   - In the right sidebar under **Notebook Settings**:
     * **Accelerator:** Select **GPU T4 x2** (Dual T4 GPUs).
     * **Internet:** Turn **ON** (Required for downloads and Gradio public link).

2. **Clone the Repo or Upload Files**:
   ```bash
   !git clone <your-repo-url> /kaggle/working/Omni-videos-custom-auto_prompt_high-quality
   %cd /kaggle/working/Omni-videos-custom-auto_prompt_high-quality
   ```

3. **Install Dependencies (Disk-Optimized)**:
   ```bash
   !pip install --no-cache-dir -r requirements.txt
   ```

4. **Launch Application**:
   ```bash
   !python kaggle_setup.py
   ```
   Or open and run `Omni_Video_Factory_Kaggle.ipynb` directly.

5. **(Optional) Instant Boot via Kaggle Dataset**:
   - Upload the 4 model `.safetensors` files to a Kaggle Dataset (or search for an existing public Wan 2.1 dataset).
   - In the notebook, click **+ Add Input -> Your Datasets** and attach it.
   - The app will discover and symlink the models immediately, starting up in seconds.


