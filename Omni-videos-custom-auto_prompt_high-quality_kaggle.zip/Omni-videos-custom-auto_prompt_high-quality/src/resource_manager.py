# ==============================================================================
# Omni Video Factory - Resource Manager & Memory Optimizer
# ==============================================================================
# Specifically designed for resource-constrained environments like Google Colab:
# - GPU VRAM: ~15 GB (T4/V100)
# - System RAM: ~12 GB
# - Temporary Disk: ~107 GB
# ==============================================================================

import gc
import logging
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("omni_resource_manager")


def _get_app_config():
    try:
        import config
        return config
    except Exception:
        try:
            import sys
            mod = sys.modules.get("src.app_lib")
            if mod is not None:
                return getattr(mod, "APP_CONFIG", None)
        except Exception:
            pass
    return None


def is_kaggle_environment() -> bool:
    """Detect if the current runtime is inside Kaggle notebooks."""
    return (
        os.path.exists("/kaggle")
        or bool(os.getenv("KAGGLE_KERNEL_RUN_TYPE"))
        or bool(os.getenv("KAGGLE_URL_BASE"))
    )


def get_vram_info() -> Dict[str, Any]:
    """Inspect GPU VRAM usage via PyTorch CUDA APIs across all available GPUs."""
    info = {
        "available": False,
        "name": "N/A",
        "used_mb": 0.0,
        "free_mb": 0.0,
        "total_mb": 0.0,
        "percent": 0.0,
        "allocated_mb": 0.0,
        "reserved_mb": 0.0,
        "device_count": 0,
        "devices": [],
    }
    try:
        import torch
        if torch.cuda.is_available():
            info["available"] = True
            dev_count = torch.cuda.device_count()
            info["device_count"] = dev_count

            devices_list = []
            agg_used = 0.0
            agg_free = 0.0
            agg_total = 0.0
            agg_allocated = 0.0
            agg_reserved = 0.0

            for d in range(dev_count):
                dev_name = torch.cuda.get_device_name(d)
                free_bytes, total_bytes = torch.cuda.mem_get_info(d)
                used_bytes = total_bytes - free_bytes
                d_total_mb = round(total_bytes / (1024 ** 2), 1)
                d_free_mb = round(free_bytes / (1024 ** 2), 1)
                d_used_mb = round(used_bytes / (1024 ** 2), 1)
                d_percent = round((used_bytes / total_bytes) * 100.0, 1) if total_bytes > 0 else 0.0
                d_allocated = round(torch.cuda.memory_allocated(d) / (1024 ** 2), 1)
                d_reserved = round(torch.cuda.memory_reserved(d) / (1024 ** 2), 1)

                agg_used += d_used_mb
                agg_free += d_free_mb
                agg_total += d_total_mb
                agg_allocated += d_allocated
                agg_reserved += d_reserved

                devices_list.append({
                    "id": d,
                    "name": dev_name,
                    "total_mb": d_total_mb,
                    "free_mb": d_free_mb,
                    "used_mb": d_used_mb,
                    "percent": d_percent,
                    "allocated_mb": d_allocated,
                    "reserved_mb": d_reserved,
                })

            info["devices"] = devices_list
            curr_dev = torch.cuda.current_device() if dev_count > 0 else 0
            primary = devices_list[curr_dev] if curr_dev < len(devices_list) else (devices_list[0] if devices_list else None)
            if primary:
                info["name"] = primary["name"] if dev_count == 1 else f"{primary['name']} (x{dev_count})"
                info["total_mb"] = primary["total_mb"]
                info["free_mb"] = primary["free_mb"]
                info["used_mb"] = primary["used_mb"]
                info["percent"] = primary["percent"]
                info["allocated_mb"] = primary["allocated_mb"]
                info["reserved_mb"] = primary["reserved_mb"]
                info["agg_total_mb"] = round(agg_total, 1)
                info["agg_free_mb"] = round(agg_free, 1)
                info["agg_used_mb"] = round(agg_used, 1)
    except Exception as exc:
        logger.debug(f"Failed to query VRAM info: {exc}")
    return info


def get_ram_info() -> Dict[str, Any]:
    """Inspect host System RAM usage via psutil."""
    info = {
        "used_mb": 0.0,
        "free_mb": 0.0,
        "total_mb": 0.0,
        "percent": 0.0,
    }
    try:
        import psutil
        vm = psutil.virtual_memory()
        info["total_mb"] = round(vm.total / (1024 ** 2), 1)
        info["used_mb"] = round(vm.used / (1024 ** 2), 1)
        info["free_mb"] = round(vm.available / (1024 ** 2), 1)
        info["percent"] = round(vm.percent, 1)
    except Exception as exc:
        logger.debug(f"Failed to query RAM info: {exc}")
    return info


def get_swap_info() -> Dict[str, Any]:
    """Inspect host swap memory usage via psutil."""
    info = {
        "enabled": False,
        "used_mb": 0.0,
        "free_mb": 0.0,
        "total_mb": 0.0,
        "percent": 0.0,
    }
    try:
        import psutil
        sm = psutil.swap_memory()
        info["total_mb"] = round(sm.total / (1024 ** 2), 1)
        info["used_mb"] = round(sm.used / (1024 ** 2), 1)
        info["free_mb"] = round(sm.free / (1024 ** 2), 1)
        info["percent"] = round(sm.percent, 1)
        info["enabled"] = sm.total > (512 * 1024 ** 2)
    except Exception as exc:
        logger.debug(f"Failed to query swap info: {exc}")
    return info


def get_disk_info(target_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Inspect filesystem disk usage for the workspace partition."""
    info = {
        "total_gb": 0.0,
        "used_gb": 0.0,
        "free_gb": 0.0,
        "percent": 0.0,
    }
    try:
        check_path = target_dir or Path(__file__).resolve().parent.parent
        usage = shutil.disk_usage(str(check_path))
        info["total_gb"] = round(usage.total / (1024 ** 3), 1)
        info["used_gb"] = round(usage.used / (1024 ** 3), 1)
        info["free_gb"] = round(usage.free / (1024 ** 3), 1)
        info["percent"] = round((usage.used / usage.total) * 100.0, 1) if usage.total > 0 else 0.0
    except Exception as exc:
        logger.debug(f"Failed to query disk info: {exc}")
    return info


def get_temp_files_info(temp_dirs: Optional[List[Path]] = None) -> Dict[str, Any]:
    """Count and calculate total size of intermediate temporary files."""
    repo_dir = Path(__file__).resolve().parent.parent
    if temp_dirs is None:
        temp_dirs = [
            repo_dir / "datas" / "temp",
            repo_dir / "ComfyUIVideo" / "temp",
            repo_dir / "ComfyUIVideo" / "output",
        ]
    total_files = 0
    total_bytes = 0
    for d in temp_dirs:
        if not d.exists():
            continue
        try:
            for item in d.rglob("*"):
                if item.is_file():
                    total_files += 1
                    try:
                        total_bytes += item.stat().st_size
                    except Exception:
                        pass
        except Exception:
            pass
    return {
        "file_count": total_files,
        "size_mb": round(total_bytes / (1024 ** 2), 1),
    }


def get_complete_resource_snapshot(repo_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Comprehensive snapshot of all critical resources."""
    return {
        "gpu": get_vram_info(),
        "ram": get_ram_info(),
        "swap": get_swap_info(),
        "disk": get_disk_info(repo_dir),
        "temp": get_temp_files_info(),
    }


def format_resource_status_line(snapshot: Optional[Dict[str, Any]] = None) -> str:
    """Format resource usage into a clean, human-readable status text."""
    if snapshot is None:
        snapshot = get_complete_resource_snapshot()
    gpu = snapshot["gpu"]
    ram = snapshot["ram"]
    swap = snapshot.get("swap", get_swap_info())
    disk = snapshot["disk"]
    temp = snapshot["temp"]

    if gpu["available"]:
        gpu_str = f"GPU: {gpu['used_mb']:.0f}/{gpu['total_mb']:.0f}MB ({gpu['percent']:.0f}%)"
    else:
        gpu_str = "GPU: N/A"

    ram_str = f"RAM: {ram['used_mb']:.0f}/{ram['total_mb']:.0f}MB ({ram['percent']:.0f}%)"
    if swap.get("enabled"):
        ram_str += f" [Swap: {swap['used_mb']:.0f}/{swap['total_mb']:.0f}MB]"

    disk_str = f"Disk: {disk['free_gb']:.1f}GB free / {disk['total_gb']:.1f}GB ({disk['percent']:.0f}% used)"
    temp_str = f"Temp: {temp['file_count']} files ({temp['size_mb']:.1f}MB)"

    return f"📊 Resources: {gpu_str} | {ram_str} | {disk_str} | {temp_str}"


def check_resource_warnings(snapshot: Optional[Dict[str, Any]] = None) -> List[str]:
    """Check if any resource is dangerously close to exhaustion."""
    if snapshot is None:
        snapshot = get_complete_resource_snapshot()
    cfg = _get_app_config()
    vram_thresh = float(getattr(cfg, "VRAM_WARNING_THRESHOLD_PERCENT", 90.0))
    ram_thresh = float(getattr(cfg, "RAM_WARNING_THRESHOLD_PERCENT", 85.0))
    disk_thresh = float(getattr(cfg, "DISK_WARNING_THRESHOLD_PERCENT", 90.0))

    warnings = []
    gpu = snapshot["gpu"]
    ram = snapshot["ram"]
    disk = snapshot["disk"]

    if gpu["available"] and gpu["percent"] >= vram_thresh:
        warnings.append(
            f"⚠️ VRAM usage high: {gpu['percent']:.1f}% ({gpu['used_mb']:.0f}/{gpu['total_mb']:.0f} MB). "
            f"Risk of CUDA Out of Memory."
        )
    if ram["percent"] >= ram_thresh:
        warnings.append(
            f"⚠️ Host RAM usage high: {ram['percent']:.1f}% ({ram['used_mb']:.0f}/{ram['total_mb']:.0f} MB). "
            f"Risk of Colab kernel crash."
        )
    if disk["percent"] >= disk_thresh or disk["free_gb"] < 3.0:
        warnings.append(
            f"⚠️ Disk space critically low: {disk['free_gb']:.1f} GB free ({disk['percent']:.1f}% used). "
            f"Risk of disk exhaustion."
        )
    return warnings


# ------------------------------------------------------------------------------
# Memory Management & Cleanup Functions
# ------------------------------------------------------------------------------

def free_gpu_memory(aggressive: bool = False) -> None:
    """
    Safely release unused GPU memory without hurting active loops.
    Invokes ComfyUI model management and PyTorch cache reclamation.
    """
    # 1. ComfyUI model management cleanup
    try:
        import comfy.model_management as mm
        if hasattr(mm, "soft_empty_cache"):
            mm.soft_empty_cache()
        if aggressive and hasattr(mm, "cleanup_models"):
            mm.cleanup_models()
    except Exception:
        pass

    # 2. Host Python garbage collection
    gc.collect()

    # 3. PyTorch CUDA cache reclamation across all GPUs
    try:
        import torch
        if torch.cuda.is_available():
            dev_count = torch.cuda.device_count()
            for d in range(dev_count):
                with torch.cuda.device(d):
                    if aggressive or get_vram_info().get("percent", 0) > 80.0:
                        torch.cuda.empty_cache()
                        if hasattr(torch.cuda, "ipc_collect"):
                            torch.cuda.ipc_collect()
    except Exception:
        pass


def unload_all_models_from_vram() -> None:
    """Completely unload all active models from VRAM back to CPU/disk."""
    try:
        import comfy.model_management as mm
        if hasattr(mm, "unload_all_models"):
            mm.unload_all_models()
        elif hasattr(mm, "cleanup_models"):
            mm.cleanup_models()
    except Exception:
        pass
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            for d in range(torch.cuda.device_count()):
                with torch.cuda.device(d):
                    torch.cuda.empty_cache()
    except Exception:
        pass


def clean_temp_files(
    temp_dirs: Optional[List[Path]] = None,
    max_age_hours: float = 2.0,
    force_all: bool = False,
) -> int:
    """
    Delete temporary and intermediate files (PNG frames, temp chunks, latents).
    Returns the number of deleted files.
    """
    repo_dir = Path(__file__).resolve().parent.parent
    if temp_dirs is None:
        temp_dirs = [
            repo_dir / "datas" / "temp",
            repo_dir / "ComfyUIVideo" / "temp",
            repo_dir / "ComfyUIVideo" / "output",
        ]

    now = time.time()
    age_cutoff_seconds = max_age_hours * 3600.0
    deleted_count = 0

    for d in temp_dirs:
        if not d.exists():
            continue
        try:
            for item in d.rglob("*"):
                if not item.is_file():
                    continue
                # Do not delete final MP4s in datas/outputs/!
                if "datas" in item.parts and "outputs" in item.parts:
                    continue
                try:
                    mtime = item.stat().st_mtime
                    if force_all or (now - mtime) > age_cutoff_seconds:
                        item.unlink(missing_ok=True)
                        deleted_count += 1
                except Exception:
                    pass
        except Exception:
            pass

    return deleted_count


def clean_hf_cache() -> int:
    """
    Clean Hugging Face hub cache directory (~/.cache/huggingface/hub).
    Since models are permanently located in ComfyUIVideo/models/, keeping
    a second 36.7 GB copy in HF cache would easily blow past the 107 GB disk.
    """
    hf_hub_cache = Path.home() / ".cache" / "huggingface" / "hub"
    deleted_count = 0
    if hf_hub_cache.exists():
        try:
            for item in hf_hub_cache.iterdir():
                if item.is_dir() and item.name.startswith("models--"):
                    shutil.rmtree(item, ignore_errors=True)
                    deleted_count += 1
                elif item.is_file():
                    item.unlink(missing_ok=True)
                    deleted_count += 1
        except Exception as exc:
            logger.debug(f"HF cache cleanup skipped: {exc}")
    return deleted_count


def clean_pip_cache() -> None:
    """Clean pip wheel cache in ~/.cache/pip."""
    pip_cache = Path.home() / ".cache" / "pip"
    if pip_cache.exists():
        try:
            shutil.rmtree(pip_cache, ignore_errors=True)
        except Exception:
            pass


def prune_output_videos(output_dir: Path, max_keep: int = 20) -> int:
    """Retain only the latest max_keep videos in output directory to prevent disk buildup."""
    if not output_dir.exists() or max_keep <= 0:
        return 0
    videos = []
    try:
        for f in output_dir.glob("*.mp4"):
            if f.is_file():
                videos.append(f)
        videos.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    except Exception:
        return 0

    deleted = 0
    if len(videos) > max_keep:
        for old_video in videos[max_keep:]:
            try:
                old_video.unlink(missing_ok=True)
                deleted += 1
            except Exception:
                pass
    return deleted


def emergency_cleanup() -> str:
    """
    Emergency cleanup routine triggered on OOM, critical disk level, or pipeline error.
    Returns a summary report of cleaned items.
    """
    unloaded_models = False
    try:
        unload_all_models_from_vram()
        unloaded_models = True
    except Exception:
        pass

    deleted_temp = clean_temp_files(force_all=True)
    clean_hf_cache()
    clean_pip_cache()

    snapshot = get_complete_resource_snapshot()
    report = (
        f"🧹 Emergency cleanup completed: "
        f"Models unloaded={unloaded_models}, Temp files deleted={deleted_temp}. "
        f"Current: VRAM {snapshot['gpu']['percent']}%, RAM {snapshot['ram']['percent']}%, "
        f"Disk {snapshot['disk']['free_gb']}GB free."
    )
    logger.warning(report)
    return report


def setup_colab_swap(swap_size_gb: Optional[int] = None, swap_path: Optional[str] = None) -> Tuple[bool, str]:
    """
    Automate creation of Linux swap file on Google Colab NVMe storage.
    Expands host virtual memory from 12.6 GB to 24+ GB, completely eliminating
    the Linux OOM killer termination when 14B models offload during VAE decode.
    """
    import subprocess
    cfg = _get_app_config()
    enabled = bool(getattr(cfg, "ENABLE_COLAB_SWAP", True))
    if not enabled:
        return False, "Colab swap configuration is disabled in config.py"

    size_gb = swap_size_gb or int(getattr(cfg, "COLAB_SWAP_SIZE_GB", 12))
    target_path = swap_path or str(getattr(cfg, "COLAB_SWAP_FILE_PATH", "/content/swapfile"))

    if not sys.platform.startswith("linux"):
        return False, "Swap configuration only applicable on Linux environments"

    # Check if swap is already sufficiently active
    swap_info = get_swap_info()
    if swap_info["enabled"] and swap_info["total_mb"] >= 4000:
        return True, f"Swap already active ({swap_info['total_mb'] / 1024:.1f} GB)"

    # Verify free disk space before allocating swapfile
    target_parent = Path(target_path).parent if os.path.exists(Path(target_path).parent) else Path("/content")
    disk_info = get_disk_info(target_parent if target_parent.exists() else Path("."))
    if disk_info["free_gb"] < (size_gb + 3.0):
        return False, f"Insufficient disk space for {size_gb}GB swap ({disk_info['free_gb']:.1f}GB free)"

    try:
        # 1. Allocate swapfile (fallocate is instant on ext4 NVMe)
        alloc_res = subprocess.run(["fallocate", "-l", f"{size_gb}G", target_path], capture_output=True, text=True)
        if alloc_res.returncode != 0:
            dd_res = subprocess.run(["dd", "if=/dev/zero", f"of={target_path}", "bs=1M", f"count={size_gb * 1024}"], capture_output=True, text=True)
            if dd_res.returncode != 0:
                return False, f"Failed allocating swapfile: {alloc_res.stderr} / {dd_res.stderr}"

        # 2. Restrict permissions (required by mkswap)
        subprocess.run(["chmod", "600", target_path], check=True)

        # 3. Format as swap
        subprocess.run(["mkswap", target_path], check=True, capture_output=True)

        # 4. Activate swap
        subprocess.run(["swapon", target_path], check=True, capture_output=True)

        # 5. Tune swappiness (standard 60)
        try:
            with open("/proc/sys/vm/swappiness", "w") as f:
                f.write("60\n")
        except Exception:
            pass

        new_swap = get_swap_info()
        return True, f"Successfully activated {new_swap['total_mb'] / 1024:.1f} GB Linux swap at {target_path}"
    except Exception as exc:
        return False, f"Error configuring swap: {exc}"


def find_kaggle_dataset_models(model_filenames: List[str], input_dir: Optional[str] = None) -> Dict[str, Path]:
    """
    Search Kaggle /kaggle/input directories for pre-attached model safetensors.
    Returns mapping from filename to absolute Path.
    """
    cfg = _get_app_config()
    search_dir = Path(input_dir or getattr(cfg, "KAGGLE_INPUT_DIR", "/kaggle/input"))
    found: Dict[str, Path] = {}
    if not search_dir.exists():
        return found

    needed = set(model_filenames)
    try:
        for entry in search_dir.rglob("*.safetensors"):
            if entry.name in needed:
                found[entry.name] = entry.resolve()
                needed.remove(entry.name)
            if not needed:
                break
    except Exception as exc:
        logger.warning(f"Error scanning Kaggle input datasets: {exc}")
    return found


def setup_kaggle_environment() -> Tuple[bool, str]:
    """
    Verify and configure the Kaggle runtime environment:
    1. Verify 2*T4 GPU availability and multi-GPU settings.
    2. Check storage (/kaggle/working 20GB limit vs /tmp 73GB).
    3. Prepare /tmp/omni_models and /tmp/omni_temp scratch spaces.
    4. Auto-discover model files attached via Kaggle datasets in /kaggle/input.
    """
    if not is_kaggle_environment():
        return False, "Not running in a Kaggle environment."

    cfg = _get_app_config()
    lines = ["[kaggle] initializing Kaggle 2*T4 GPU runtime environment"]

    # 1. GPU Check
    try:
        import torch
        if torch.cuda.is_available():
            num_gpus = torch.cuda.device_count()
            gpu_names = [f"GPU {i}: {torch.cuda.get_device_name(i)}" for i in range(num_gpus)]
            lines.append(f"- Detected {num_gpus} CUDA GPU(s): {', '.join(gpu_names)}")
            if num_gpus >= 2:
                lines.append("- Dual T4 GPU acceleration enabled: both GPUs will be actively utilized!")
        else:
            lines.append("⚠️ WARNING: No CUDA GPU detected! Please enable GPU T4 x2 in Notebook Settings.")
    except Exception as exc:
        lines.append(f"⚠️ Warning querying GPUs: {exc}")

    # 2. Disk & Directory Check
    working_disk = get_disk_info(Path("/kaggle/working"))
    tmp_disk = get_disk_info(Path("/tmp"))
    lines.append(f"- Working disk (/kaggle/working): {working_disk['free_gb']} GB free / {working_disk['total_gb']} GB total")
    lines.append(f"- Scratch disk (/tmp): {tmp_disk['free_gb']} GB free / {tmp_disk['total_gb']} GB total")

    # 3. Setup /tmp scratch dirs to avoid filling 20GB working disk
    redirect_tmp = bool(getattr(cfg, "KAGGLE_REDIRECT_MODELS_TO_TMP", True))
    tmp_models_dir = Path(getattr(cfg, "KAGGLE_TMP_MODELS_DIR", "/tmp/omni_models"))
    if redirect_tmp:
        tmp_models_dir.mkdir(parents=True, exist_ok=True)
        lines.append(f"- Fast scratch model cache configured at: {tmp_models_dir}")

    # 4. Check for attached datasets
    input_dir = Path(getattr(cfg, "KAGGLE_INPUT_DIR", "/kaggle/input"))
    if input_dir.exists():
        subdirs = [p.name for p in input_dir.iterdir() if p.is_dir()]
        lines.append(f"- Detected {len(subdirs)} attached Kaggle dataset(s) in {input_dir}")

    return True, "\n".join(lines)
