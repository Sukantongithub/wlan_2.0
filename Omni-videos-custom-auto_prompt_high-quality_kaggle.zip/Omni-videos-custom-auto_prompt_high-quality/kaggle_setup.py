#!/usr/bin/env python3
"""
Omni Video Factory - Kaggle Dual T4 GPU Setup & Launch Helper
Automates Kaggle 2*T4 GPU environment verification, /tmp storage redirect (bypassing 20GB working limit),
Kaggle dataset model auto-discovery, dependency installation, and launches the app with public URL.
"""

import os
import sys
import shutil
import subprocess
import urllib.request
from pathlib import Path


def print_banner(text: str) -> None:
    print("\n" + "=" * 70)
    print(f"  {text}")
    print("=" * 70)


def check_kaggle_environment():
    print_banner("1. Checking Kaggle Environment & Dual-GPU Hardware")
    is_kaggle = os.path.exists("/kaggle") or bool(os.getenv("KAGGLE_KERNEL_RUN_TYPE"))
    print(f"- Detected Kaggle environment: {is_kaggle}")

    # Check GPU(s)
    try:
        import torch
        if torch.cuda.is_available():
            dev_count = torch.cuda.device_count()
            print(f"- CUDA Available: True (Detected {dev_count} GPU device(s))")
            for d in range(dev_count):
                gpu_name = torch.cuda.get_device_name(d)
                free_b, total_b = torch.cuda.mem_get_info(d)
                print(f"  ├─ GPU {d}: {gpu_name}")
                print(f"  │   VRAM: {free_b / (1024**3):.2f} GB free / {total_b / (1024**3):.2f} GB total")
            if dev_count >= 2:
                print("✓ Dual T4 GPU configuration confirmed: 2x parallel processing active!")
            else:
                print("ℹ️ Note: Only 1 GPU detected. In Kaggle Notebook Settings (right sidebar), select 'GPU T4 x2' for 2x speed.")
        else:
            print("⚠️ WARNING: No CUDA GPU detected. Please go to Notebook Settings -> Accelerator -> GPU T4 x2.")
    except Exception as exc:
        print(f"⚠️ Warning querying GPU: {exc}")

    # Check Disk Partitions
    working_dir = Path("/kaggle/working") if os.path.exists("/kaggle/working") else Path(".")
    usage_working = shutil.disk_usage(working_dir)
    print(f"- Working Disk ({working_dir}): {usage_working.free / (1024**3):.1f} GB free / {usage_working.total / (1024**3):.1f} GB total")

    tmp_dir = Path("/tmp")
    if tmp_dir.exists():
        usage_tmp = shutil.disk_usage(tmp_dir)
        print(f"- Fast Scratch Disk (/tmp):     {usage_tmp.free / (1024**3):.1f} GB free / {usage_tmp.total / (1024**3):.1f} GB total")

    # Check Internet Connectivity
    try:
        urllib.request.urlopen("https://huggingface.co", timeout=5)
        print("- Internet Connectivity: OK (Enabled)")
    except Exception:
        print("⚠️ WARNING: Internet appears to be DISABLED.")
        print("   In Kaggle notebook right sidebar -> Settings -> Internet -> Turn ON.")


def setup_kaggle_directories():
    print_banner("2. Initializing Workspace & Disk Bypass for 20GB Kaggle Quota")
    repo_dir = Path(__file__).resolve().parent

    temp_dir = repo_dir / "datas" / "temp"
    output_dir = repo_dir / "datas" / "outputs"
    temp_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"- Temporary directory: {temp_dir}")
    print(f"- Output directory:    {output_dir}")

    # Prepare /tmp scratch space for large model files (37 GB) to protect 20GB /kaggle/working limit
    tmp_models_root = Path("/tmp/omni_models")
    tmp_models_root.mkdir(parents=True, exist_ok=True)
    os.environ["KAGGLE_TMP_MODELS_DIR"] = str(tmp_models_root)
    os.environ["KAGGLE_REDIRECT_MODELS_TO_TMP"] = "true"
    print(f"- Fast scratch model cache: {tmp_models_root} (prevents filling 20GB working quota)")

    # Check for pre-attached Kaggle datasets in /kaggle/input
    input_dir = Path("/kaggle/input")
    if input_dir.exists():
        datasets = [p.name for p in input_dir.iterdir() if p.is_dir()]
        print(f"- Attached Kaggle Datasets ({len(datasets)}): {', '.join(datasets) if datasets else 'none'}")
        if datasets:
            try:
                from src import resource_manager
                test_names = [
                    "wan_2.1_vae.safetensors",
                    "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                    "wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8High.safetensors",
                    "wan22EnhancedNSFWCameraPrompt_nsfwFASTMOVEFP8Low.safetensors",
                ]
                found = resource_manager.find_kaggle_dataset_models(test_names)
                if found:
                    print(f"✓ Found {len(found)}/{len(test_names)} required models in pre-attached Kaggle dataset(s):")
                    for fname, fpath in found.items():
                        print(f"  └─ {fname} -> {fpath}")
                    print("  💡 These models will be symlinked instantly without re-downloading!")
            except Exception as e:
                print(f"Note: dataset check: {e}")


def remove_spaces_package_if_present():
    """Hugging Face 'spaces' package injects ZeroGPU client hooks that break Gradio on external notebooks."""
    try:
        import importlib.util
        if importlib.util.find_spec("spaces") is not None:
            print_banner("3. Removing incompatible Hugging Face 'spaces' package")
            subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "spaces"], check=False)
            print("✓ Successfully uninstalled 'spaces' (prevents Gradio frontend hijacking).")
    except Exception as exc:
        print(f"Note: spaces check skipped ({exc})")


def check_and_install_dependencies():
    """Ensure all required dependencies are installed."""
    repo_dir = Path(__file__).resolve().parent
    req_file = repo_dir / "requirements.txt"
    critical_mods = ("comfy_kitchen", "torchsde", "av", "ftfy", "pydantic_settings")
    import importlib.util
    missing = [m for m in critical_mods if importlib.util.find_spec(m) is None]
    if missing:
        print_banner(f"4. Installing Required Dependencies ({', '.join(missing)})")
        if req_file.exists():
            subprocess.run([sys.executable, "-m", "pip", "install", "--no-cache-dir", "-r", str(req_file)], check=False)
        else:
            fallback = ["comfy-kitchen>=0.2.5", "torchsde", "av>=14.2.0", "ftfy>=6.2.0", "kornia>=0.7.1", "spandrel", "pydantic-settings", "alembic"]
            subprocess.run([sys.executable, "-m", "pip", "install", "--no-cache-dir"] + fallback, check=False)
        print("✓ Required dependencies installed successfully.")


def clean_pip_wheel_cache():
    """Clear pip cache to save 5-10 GB on Kaggle disk."""
    pip_cache = Path.home() / ".cache" / "pip"
    if pip_cache.exists():
        print_banner("5. Cleaning pip wheel cache to save Kaggle disk space")
        try:
            shutil.rmtree(pip_cache, ignore_errors=True)
            print("✓ Pip cache cleaned successfully.")
        except Exception as e:
            print(f"Note: pip cache cleanup skipped ({e})")

    # Also clean redundant Hugging Face hub cache if models are already placed
    try:
        from src import resource_manager
        deleted = resource_manager.clean_hf_cache()
        if deleted > 0:
            print(f"✓ Hugging Face hub cache cleaned: freed disk space from {deleted} cached repo(s).")
    except Exception:
        pass


def launch_application():
    print_banner("6. Launching Omni Video Factory on Kaggle (2*T4 GPU Acceleration)")
    repo_dir = Path(__file__).resolve().parent
    app_py = repo_dir / "app.py"

    # Enforce Gradio public sharing and multi-GPU optimization for Kaggle
    os.environ["GRADIO_SHARE"] = "true"
    os.environ["ENABLE_MULTI_GPU"] = "true"
    os.environ["KAGGLE_OPTIMIZATION_ENABLED"] = "true"

    cmd = [sys.executable, str(app_py)]
    print(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd)


if __name__ == "__main__":
    check_kaggle_environment()
    setup_kaggle_directories()
    remove_spaces_package_if_present()
    check_and_install_dependencies()
    clean_pip_wheel_cache()
    launch_application()
