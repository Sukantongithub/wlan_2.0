---
title: Omni Video Factory
emoji: 🏆
colorFrom: red
colorTo: indigo
sdk: gradio
sdk_version: 5.44.1
python_version: '3.12'
app_file: app.py
pinned: false
license: mit
short_description: text to video, image to video, video extend
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
