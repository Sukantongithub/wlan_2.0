#!/usr/bin/env python3
"""
Omni Video Factory - Google Colab Setup & Launch Helper
Automates environment verification, storage setup, and launches the app with public URL.
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path


def print_banner(text: str) -> None:
    print("\n" + "=" * 70)
    print(f"  {text}")
    print("=" * 70)


def check_colab_environment():
    print_banner("1. Checking Google Colab Environment")
    is_colab = "google.colab" in sys.modules or os.path.exists("/content")
    print(f"- Detected Google Colab environment: {is_colab}")

    # Check GPU
    try:
        import torch
        if torch.cuda.is_available():
            dev = torch.cuda.current_device()
            gpu_name = torch.cuda.get_device_name(dev)
            free_b, total_b = torch.cuda.mem_get_info(dev)
            print(f"- GPU: {gpu_name}")
            print(f"- VRAM: {free_b / (1024**3):.2f} GB free / {total_b / (1024**3):.2f} GB total")
        else:
            print("⚠️ WARNING: No CUDA GPU detected. Please go to Runtime -> Change runtime type -> T4 GPU.")
    except Exception as exc:
        print(f"⚠️ Warning querying GPU: {exc}")

    # Check Disk
    usage = shutil.disk_usage("/content" if os.path.exists("/content") else ".")
    print(f"- Disk: {usage.free / (1024**3):.1f} GB free / {usage.total / (1024**3):.1f} GB total")


def setup_colab_directories():
    print_banner("2. Initializing Optimized Workspace Directories")
    repo_dir = Path(__file__).resolve().parent

    temp_dir = repo_dir / "datas" / "temp"
    output_dir = repo_dir / "datas" / "outputs"
    temp_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"- Temporary directory: {temp_dir}")
    print(f"- Output directory:    {output_dir}")

    # Check for Google Drive mount
    gdrive_mount = Path("/content/drive/MyDrive/OmniVideo")
    if gdrive_mount.exists():
        print(f"- Detected Google Drive persistence folder: {gdrive_mount}")
        (gdrive_mount / "models").mkdir(parents=True, exist_ok=True)
        (gdrive_mount / "outputs").mkdir(parents=True, exist_ok=True)
        os.environ["ENABLE_GDRIVE_PERSISTENCE"] = "true"
        os.environ["GDRIVE_MOUNT_PATH"] = str(gdrive_mount)
    else:
        print("- Google Drive not mounted. Using local Colab fast NVMe storage.")


def remove_spaces_package_if_present():
    """Hugging Face 'spaces' package injects ZeroGPU client hooks that break Gradio on Google Colab."""
    try:
        import importlib.util
        if importlib.util.find_spec("spaces") is not None:
            print_banner("3. Removing incompatible Hugging Face 'spaces' package")
            subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "spaces"], check=False)
            print("✓ Successfully uninstalled 'spaces' (prevents Gradio frontend hijacking).")
    except Exception as exc:
        print(f"Note: spaces check skipped ({exc})")


def clean_pip_wheel_cache():
    """Clear pip cache to save 5-10 GB on Colab disk."""
    pip_cache = Path.home() / ".cache" / "pip"
    if pip_cache.exists():
        print_banner("4. Cleaning pip wheel cache to save Colab disk space")
        try:
            shutil.rmtree(pip_cache, ignore_errors=True)
            print("✓ Pip cache cleaned successfully.")
        except Exception as e:
            print(f"Note: pip cache cleanup skipped ({e})")

    # Also clean redundant Hugging Face hub cache if models are already placed
    try:
        from src import resource_manager
        deleted = resource_manager.clean_hf_cache()
        if deleted > 0:
            print(f"✓ Hugging Face hub cache cleaned: freed disk space from {deleted} cached repo(s).")
    except Exception:
        pass


def configure_colab_swap():
    """
    Colab standard T4 instances have 12.6 GB System RAM and 0 MB swap.
    During 14B video generation, offloading the 14.3 GB UNet model to CPU before VAE decode
    causes the Linux kernel OOM killer to terminate Python ('Broken Connection').
    Creating a fast NVMe swapfile expands virtual memory to 24+ GB, preventing OOM crashes.
    """
    print_banner("5. Configuring Virtual Memory (NVMe SWAP) for Colab")
    try:
        from src import resource_manager
        ok, msg = resource_manager.setup_colab_swap()
        if ok:
            print(f"✓ {msg}")
        else:
            print(f"ℹ️ Swap status: {msg}")
    except Exception as exc:
        print(f"ℹ️ Swap configuration skipped ({exc})")

    # If swap is not active, remove any lingering /content/swapfile to reclaim disk space
    swapfile = Path("/content/swapfile")
    if swapfile.exists():
        try:
            import psutil
            if psutil.swap_memory().total < (1024 ** 3):
                swapfile.unlink(missing_ok=True)
                print("✓ Reclaimed 12 GB disk space from inactive swapfile.")
        except Exception:
            pass


def launch_application():
    print_banner("6. Launching Omni Video Factory")
    repo_dir = Path(__file__).resolve().parent
    app_py = repo_dir / "app.py"

    # Enforce Gradio public sharing for Google Colab
    os.environ["GRADIO_SHARE"] = "true"

    cmd = [sys.executable, str(app_py)]
    print(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd)


if __name__ == "__main__":
    check_colab_environment()
    setup_colab_directories()
    remove_spaces_package_if_present()
    clean_pip_wheel_cache()
    configure_colab_swap()
    launch_application()
